rm(list=ls())

#### SET WD #####
setwd("/Users/chloe/Documents/Imperial (MSc)/Microbiome Performance MSc/Data/")
dir()




##### LOAD DATA #####
d <-read.csv("Microbiome_data_190819.csv", header = T)

require(dplyr)
require(ggplot2)
require(lme4)
require(cowplot)
require(lmtest)
require(ggsci)
library(MASS)

str(d)

d <- dplyr::select(d, S.SP, Sex, Group, Group.size, Bee.ID, Colony, Microbiome, Age.at.flight..days., Mill, Intertegular.distance..mm., 
                   Weight, Sucrose.consumed, Circuits, Distance..m., Mean.Speed, Flight.Time..s., Flight.Time..mins.)

d <- filter(d, Circuits != "NA")
d <- filter(d, Colony != "NA")
d <- filter(d, S.SP != "S")
d <- filter(d, Intertegular.distance..mm. != "NA")

d_C <- filter(d, Microbiome == "C")

# filter out colony-derived bees 
d <- filter(d, Microbiome != "C")
#d$Microbiome <- droplevels(d$Microbiome, exclude = "C")

# remove white space 
d$Sex <- trimws(d$Sex, which = "right")
d$Sex <- as.factor(d$Sex)
# remove invisible factor from data 
#d$S.SP <- droplevels(d$S.SP, exclude = "")

# add flight initiation column
d$Initiation[d$Distance..m. <=70] <- 0
d$Initiation[d$Distance..m. >70] <- 1

str(d)

# SUBSET into those which initiated (flew >= 70 m) and not initated flight (< 70 m)
d_F <- filter(d, Distance..m. >= 70)
d_NF <- filter(d, Distance..m. < 70)

### DIAGNOSTIC PLOTS ###

### Distance 
distance_plot <- ggplot(d, aes(x = Distance..m.)) +
  geom_histogram(binwidth=200)
# bees which initiated flight only 
distance_plot70 <- ggplot(d_F, aes(x = Distance..m.)) +
  geom_histogram(binwidth=200)
# right skew 

mean(d_F$Distance..m.)
var(d_F$Distance..m.)
median(d_F$Distance..m.)

# log data
d_F$Distance_log <- log(d_F$Distance..m.)
ggplot(d_F, aes(x = Distance_log)) +
  geom_histogram(binwidth = 0.1)

shapiro.test(d_F$Distance_log) 
# not normally distributed

### Speed 
# which initiated flight only 
speed_plot <- ggplot(d_F, aes(x = Mean.Speed)) + 
  geom_histogram(binwidth = 0.03)

### Weight 
# intiated flight only 
weight_plot <- ggplot(d_F, aes(x = Weight)) + 
  geom_histogram(binwidth = 0.02)
# normal distribution 

## group sizes 
# initiated flight only
d_F$Group.size <- as.numeric(d_F$Group.size)
group_size_plot <- ggplot(d_F, aes(x = Group.size)) + 
  geom_histogram(binwidth = 1)
d_F$Group.size <- as.factor(d_F$Group.size)
# skew towards higher group numbers 

#### intertegular distance  #####
# initiated flight 
size_plot <- ggplot(d_F, aes(x = Intertegular.distance..mm.)) + 
  geom_histogram (binwidth = 0.1)
# Normal distribution


# sucrose consumed 
# initiated flight only
sucrose_plot <- ggplot(d_F, aes(x = Sucrose.consumed)) + 
  geom_histogram (binwidth = 0.001)
# 0 inflated, left skewed

# Colony numbers 
# iniated flight only 
colony_plot <- ggplot(d_F, aes(x = Colony)) + 
  geom_histogram (binwidth = 1)

####### SUBSET further into separate data frames #######
# make colony, mill and group.size factors first
# add C in front of colony numbers 
Colony <- d$Colony
Colony <- paste("C", Colony)
Colony <- gsub(" ", "", Colony)
d$Colony <- Colony

d$Colony <- as.factor(d$Colony)
d$Mill <- as.factor(d$Mill)
d$Group.size <- as.factor(d$Group.size)

d_F <- filter(d, Distance..m. >= 70)
d_NF <- filter(d, Distance..m. < 70)

# filter into sexes
d_Fem <- filter(d, Sex == "F")
d_Male <- filter(d, Sex == "M")

# initiated flight (flew >= 70m) and by sex 
d_FF <- filter(d_F, Sex == "F")
d_FM <- filter(d_F, Sex == "M")


# into different treatments, and intiated/not initated flight
Microbiome_d <- filter(d, Microbiome == 1)
GF_d <- filter(d, Microbiome == 0)
# microbiome present 
Microbiome_d_F <- filter(Microbiome_d, Distance..m. >= 70)
Microbiome_d_NF <- filter(Microbiome_d, Distance..m. < 70)
# microbiome absent 
GF_d_F <- filter(GF_d, Distance..m. >= 70)
GF_d_NF <- filter(GF_d, Distance..m. < 70)


################# BOXPLOTS #################
# make colour blind friendly color pallette 
cbp1 <- c("#56B4E9", "#E69F00", "#999999", "#009E73",
          "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# does distance between sexes with no microbiome have same distribution?  - bees which initiated flight  
#title <- expression(paste("a) Distance flown in GM"["0"], " male and female bees which initiated flight"))

dist_boxplot_MF_GF70 <- ggplot(GF_d_F, aes(x = Sex, y = Distance..m.)) +
  geom_boxplot(aes(fill= Sex))+
  ylab("Distance (m)") +
  xlab("Sex") +
  # ggtitle(title) +
  theme_classic() +
  scale_fill_manual(values = cbp1) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(GF_d_F$Distance..m. ~ GF_d_F$Sex)
# W = 19, p-value = 0.03695-reject null - have different distributions 


# does speed between sexes have same distribution?  - all bees 
#title <- expression(paste("a) Mean velocity flown in GM"["0"], " male and female bees which initiated flight"))
speed_boxplot_MF_GF70 <- ggplot(GF_d_F, aes(x = Sex, y = Mean.Speed)) +
  geom_boxplot(aes(fill = Sex))+
  ylab("Mean velocity (m/s)") +
  xlab("Sex") +
  #ggtitle(title) +
  theme_classic() +
  scale_fill_manual(values = cbp1) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))


# does microbiome presence/absence have same distribution?
wilcox.test(GF_d_F$Mean.Speed ~ GF_d_F$Sex)
#  W = 57, p-value = 0.3929 - accept null - have identical distributions 

# combine boxplots into one graph
speed_dist_bp_MF_GF70 <- plot_grid(dist_boxplot_MF_GF70, speed_boxplot_MF_GF70)

# median and mean values 
aggregate(GF_d_F[, 14:15], list(GF_d_F$Sex), FUN = mean)
aggregate(GF_d_F[, 14:15], list(GF_d_F$Sex), FUN = median)

# does distance between sexes have same distribution?  - bees which initiated flight 
dist_boxplot_MF70 <- ggplot(d_F, aes(x = Sex, y = Distance..m.)) +
  geom_boxplot(aes(fill = Sex))+
  ylab("Distance (m)") +
  xlab("Sex") +
  #ggtitle("a) Distance flown in male and\nfemale bees which initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp1) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(d_F$Distance..m. ~ d_F$Sex)
#  p-value = 0.006011 - reject null - have different distributions 

# does speed between sexes have same distribution?  - bees which initiated flight 
speed_boxplot_MF70 <- ggplot(d_F, aes(x = Sex, y = Mean.Speed)) +
  geom_boxplot(aes(fill = Sex))+
  ylab("Mean velocity (m/s)") +
  xlab("Sex") +
  #ggtitle("b) Mean velocity flown in male and\nfemale bees which initiated flight") + 
  theme_classic() +
  scale_fill_manual(values = cbp1) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(d_F$Mean.Speed ~ d_F$Sex)
#  p-value = 0.2771 - accept null - have identical distributions 

# combine boxplots into one graph 
speed_dist_bp_MF70 <- plot_grid(dist_boxplot_MF70, speed_boxplot_MF70)

# color-blind pallette 2
cbp2 <- c( "#009E73","#CC79A7","#999999", "#E69F00", "#56B4E9",
           "#F0E442", "#0072B2", "#D55E00")

# Microbiome treatment vs distance - all bees 
dist_boxplot_treat <- ggplot(d, aes(x = Microbiome, y = Distance..m. )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Distance (m)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("a) Distance flown by treatment type\nin all bees") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(d$Distance..m. ~ d$Microbiome)
# W = 3091, p-value = 0.859

# Microbiome treatment vs mean speed - all bees 
speed_boxplot_treat <- ggplot(d, aes(x = Microbiome, y = Mean.Speed )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Mean velocity (m/s)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("a) Mean velocity of flight by treatment type\nin all bees") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(d$Mean.Speed ~ d$Microbiome)
# W = 2736, p-value = 0.2859

# combine boxplots 
speed_dist_bp_treat <- plot_grid(dist_boxplot_treat, speed_boxplot_treat)

# get means and medians for each treatment group
aggregate(d[, 14:15], list(d$Microbiome), FUN = mean)
aggregate(d[, 14:15], list(d$Microbiome), FUN = median)

# Microbiome treatment vs distance - all bees which flew >70m 
dist_boxplot70 <- ggplot(d_F, aes(x = Microbiome, y = Distance..m. )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Distance (m)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("a) Distance flown by treatment type\nin bees which initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(d_F$Distance..m. ~ d_F$Microbiome)
#  W = 311, p-value = 0.04997

# microbiome on mean speed in all bees which initiated flight (flew >70m) 
speed_boxplot70 <- ggplot(d_F, aes(x = Microbiome, y = Mean.Speed)) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Mean velocity (m/s)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("b) Mean velocity flown by treatment type\nin bees which initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absence have same distribution?
wilcox.test(d_F$Mean.Speed ~ d_F$Microbiome)
#  W = 209, p-value = 0.6211 - accept null - have identical distributions 

# combine into one graph
speed_dist_bp_microbiome70 <- plot_grid(dist_boxplot70, speed_boxplot70)

# calculate mean and medians for each treatment group
aggregate(d_F[, 14:15], list(d_F$Microbiome), FUN = mean)
aggregate(d_F[, 14:15], list(d_F$Microbiome), FUN = median)

# all females only 
female_dist_boxplot <- ggplot(d_Fem, aes(x = Microbiome, y = Distance..m. )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Distance (m)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("a) Distance flown in microbiome\npresent/absent female worker bees") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absencein female bees have same distribution?
wilcox.test(d_Fem$Distance..m. ~ d_Fem$Microbiome)
# W = 2142, p-value = 0.2774 = same distribution

female_speed_bp <- ggplot(d_Fem, aes(x = Microbiome, y = Mean.Speed )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Mean velocity (m/s)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("b) Mean velocity flown in microbiome\npresent/absent female worker bees") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does speed between microbiome treatment in females have same distributions?
wilcox.test(d_Fem$Mean.Speed ~ d_Fem$Microbiome)
# W = 2133, p-value = 0.2612 = same distribution

# combine to one graph
speed_dist_bp_microbiome_Fem <- plot_grid(female_dist_boxplot, female_speed_bp)

# all females which initiated flight
female70_dist_boxplot <- ggplot(d_FF, aes(x = Microbiome, y = Distance..m. )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Distance (m)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("a) Distance flown in microbiome\npresent/absent female worker bees\nwhich initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does microbiome presence/absencein female bees have same distribution?
wilcox.test(d_FF$Distance..m. ~ d_FF$Microbiome)
#   W = 173, p-value = 0.4487 - accept null - have identical distributions 

# Speed - females which flew >70 m
female70_speed_bp <- ggplot(d_FF, aes(x = Microbiome, y = Mean.Speed )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Mean velocity (m/s)") +
  xlab("Microbiome treatment") +
  scale_x_discrete(labels = expression("GM"["0"], "GM"["1"]))+
  #ggtitle("b) Mean velocity flown in microbiome\npresent/absent female worker bees\nwhich initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does speed between microbiome treatment in females have same distributions?
wilcox.test(d_FF$Mean.Speed ~ d_FF$Microbiome)
#  W = 151, p-value = 0.9741- accept null - distributions between male and female are same 

# combine into one graph
speed_dist_bp_microbiome_F70 <- plot_grid(female70_dist_boxplot, female70_speed_bp)

# get means and median for each treatment 
aggregate(d_FF[, 14:15], list(d_FF$Microbiome), FUN = mean)
aggregate(d_FF[, 14:15], list(d_FF$Microbiome), FUN = median)

# males - no data for males in microbiome group
male_boxplot <- ggplot(d_FM, aes(x = Microbiome, y = Distance..m. )) +
  geom_boxplot(aes(fill = Microbiome))+
  ylab("Distance (m)") +
  xlab("") +
  scale_x_discrete( labels = c("Microbiome absent"))+
  geom_jitter() +
  #ggtitle("Distance flown by treatment type in male bees") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none")

# colony vs distance for all bees 
colony_bp_dist <- ggplot()+
  geom_boxplot(data = d_F, aes(x = Colony, y = Distance..m., fill = Colony)) +
  ylab("Distance (m)") +
  xlab("Colony") +
  #ggtitle("a) Distance flown per colony by all bees\nwhich initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does ditance between colonies have same distrubtion
kruskal.test(Distance..m. ~ Colony, data = d_F)
#  chi-squared = 8.5356, df = 4, p-value = 0.07381- reject null hypothesis; the distributions between each colony are not identical  

colony_bp_speed <- ggplot()+
  geom_boxplot(data = d_F, aes(x = Colony, y = Mean.Speed, fill = Colony)) +
  ylab("Mean velocity (m/s)") +
  xlab("Colony") +
  # ggtitle("b) Mean velocity flown per colony by all bees\n which initiated flight") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  theme(legend.position = "none") +
  theme(text = element_text(size=14))

# does speed between colonies have same distrubtion
kruskal.test(Mean.Speed ~ Colony, data = d_F)
#   chi-squared = 5.8024, df = 4, p-value = 0.2144 - accept null hypothesis; the distributions between each colony are the same

# combine into on graph
speed_dist_bp_colony_70 <- plot_grid(colony_bp_dist, colony_bp_speed)

# gets means and medians for each colony 
aggregate(d_F[, 14:15], list(d_F$Colony), FUN = mean)
aggregate(d_F[, 14:15], list(d_F$Colony), FUN = median)

###### SUCROSE ANALYSES ######


##### 1)  does sucrose consumed affect flight? ####

# all bees - flight initiation 
ggplot(d, aes(x = Sucrose.consumed, y = Initiation)) +
  geom_point(aes(color = Microbiome))

# Binomial model 
sucro_mod1 <- glmer(Initiation ~ Sucrose.consumed + Microbiome + Sex + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ = 0, family = binomial, data = d)
summary(sucro_mod1)

sucro_mod2 <- glmer(Initiation ~ Sucrose.consumed + Microbiome + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ = 0, family = binomial, data = d)
summary(sucro_mod2)

anova(sucro_mod1, sucro_mod2)
# mod1 better

sucro_mod3 <- glmer(Initiation ~ Sucrose.consumed + Sex + Microbiome + (1|Intertegular.distance..mm.), nAGQ = 0,  family = binomial, data = d)
summary(sucro_mod3)
# mod1 better 

sucro_mod4 <- glmer(Initiation ~ Sucrose.consumed + Microbiome + Sex + (1|Colony), nAGQ = 0, family = binomial, data = d)
summary(sucro_mod4)

anova(sucro_mod1, sucro_mod4)
# mod4 better 

sucro_mod5 <- glmer(Initiation ~ Sucrose.consumed + Sex + (1|Colony), nAGQ = 0, family = binomial, data = d)
summary(sucro_mod5)

anova(sucro_mod4, sucro_mod5)
# mod5 better 

# compare with normal glm 
sucro_glm <- glm(Initiation ~ Sucrose.consumed + Sex + Colony, family = binomial, data = d)
summary(sucro_glm)

anova(sucro_mod5, sucro_glm)
# glm model better 

sucro_glm2 <- glm(Initiation ~ Sucrose.consumed + Sex*Colony, family = binomial, data = d)
summary(sucro_glm2)

anova(sucro_glm, sucro_glm2)
# sucro_glm2 better

sucro_glm3 <- glm(Initiation ~ Sucrose.consumed*Sex + Colony, family = binomial, data = d)
summary(sucro_glm3)

anova(sucro_glm1, sucro_glm3)
# sucro_glm better

# check dispersion
sucro_glm$deviance/sucro_glm$df.residual
#  0.959499 dispersion ok 


## predict model values ##
sucro_temp <- d_F[, c("Sucrose.consumed", "Sex", "Colony")]
val <- with(d_F, seq(from = min(Sucrose.consumed), to = max(Sucrose.consumed), length.out = 100))

pp <- lapply(val, function(j) {
  sucro_temp$Sucrose.consumed <- j
  predict(sucro_glm, newdata = sucro_temp, type = "response")
})

sapply(pp[c(1, 20, 40, 60, 80, 100)], mean)

plotdat <- t(sapply(pp, function(x) {
  c(M = mean(x), quantile(x, c(0.25, 0.75)))
}))

plotdat <- as.data.frame(cbind(plotdat, val))

colnames(plotdat) <- c("Predicted", "Lower", "Upper", "Sucrose.consumed")

ggplot(plotdat, aes(x = Sucrose.consumed, y = Predicted)) + 
  geom_line() +
  ylim(c(0, 1))

sucro_init_plot <- ggplot(plotdat, aes(x = Sucrose.consumed, y = Predicted)) + 
  geom_ribbon(aes(ymin = Lower, ymax = Upper), alpha = 0.1) + 
  geom_line(size = 1) + ylim(c(0, 1))+
  ylab("Flight initiation") +
  xlab("Sucrose consumed (g)") +
  ggtitle("Effect of sucrose consumed prior to flight trial on flight initiation") +
  theme_minimal() +
  scale_color_npg() +
  theme(text = element_text(size=14))

##### 2) Bees which initiated flight (flew >70m) - does sucrose influence total distance flown?? #####
ggplot(d_F, aes(x = Sucrose.consumed, y = Distance..m.)) +
  geom_point(aes(color = Microbiome))

sucro_mod1 <- glmer(Distance..m. ~ Sucrose.consumed + Microbiome + Sex + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(sucro_mod1)

sucro_mod2 <- glmer(Distance..m. ~ Sucrose.consumed + Microbiome + Sex + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(sucro_mod2)

anova(sucro_mod1, sucro_mod2)
# mod 2 better 

sucro_mod3 <- glmer(Distance..m. ~ Sucrose.consumed + Microbiome + Sex + (1|Colony), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(sucro_mod3)
# sex no longer sig 

anova(sucro_mod2, sucro_mod3)
# mod2 better 

sucro_mod4 <- glmer(Distance..m. ~ Sucrose.consumed + Microbiome + Sex + (1|Intertegular.distance..mm.), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(sucro_mod4)

anova(sucro_mod2, sucro_mod4)
# mod 2 better 

sucro_mod5 <- glmer(Distance..m. ~ Sucrose.consumed + Microbiome + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(sucro_mod5)

lrtest(sucro_mod2, sucro_mod5)
# mod2 better 

sucro_glm <- glm(Distance..m. ~ Sucrose.consumed + Microbiome + Intertegular.distance..mm. + Sex + Colony, family = Gamma(link = log), data = d_F)
summary(sucro_glm)

anova(sucro_mod2, sucro_glm)
# mod2 better

## Predict model vals ##
sucro_temp <- d_F[, c("Sucrose.consumed", "Microbiome", "Intertegular.distance..mm.", "Sex" ,"Colony")]
val <- with(d_F, seq(from = min(Sucrose.consumed), to = max(Sucrose.consumed), length.out = 100))

pp <- lapply(val, function(j) {
  sucro_temp$Sucrose.consumed <- j
  predict(sucro_mod2, newdata = sucro_temp, type = "response")
})

sapply(pp[c(1, 20, 40, 60, 80, 100)], mean)

plotdat <- t(sapply(pp, function(x) {
  c(M = mean(x), quantile(x, c(0.25, 0.75)))
}))

plotdat <- as.data.frame(cbind(plotdat, val))

colnames(plotdat) <- c("Predicted", "Lower", "Upper", "Sucrose.consumed")


sucro_dist <- ggplot(plotdat, aes(x = Sucrose.consumed, y = Predicted)) + 
  geom_ribbon(aes(ymin = Lower, ymax = Upper), alpha = 0.2) + 
  geom_line(size = 1) + 
  ylim(c(0, 1000))+
  ylab("Distance (m)") +
  xlab("Sucrose consumed (g)") +
  ggtitle("Influence of sucrose consumed prior to flight on distance flown") +
  theme_minimal()+
  scale_fill_npg() +
  theme(legend.position = "none")+
  theme(text = element_text(size=14))

# doesn't appear to be any link between whether sucrose was consumed before flight and distance flown

##### 3) does sucrose consumed affect mean speed of flight in those that initiated? #####
ggplot()+
  geom_point(data = d_F, aes(x = Sucrose.consumed, y = Mean.Speed))

sucro_mod1 <- lmer(Mean.Speed ~ Sucrose.consumed + Microbiome + Sex + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), data = d_F)
summary(sucro_mod1)
# not  converged 

sucro_mod2 <- lmer(Mean.Speed ~ Sucrose.consumed + Sex + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), data = d_F)
summary(sucro_mod2)
# not  converged 

anova(sucro_mod1, sucro_mod2)
# mod 2 better 

sucro_mod3 <- lmer(Mean.Speed ~ Sucrose.consumed + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), data = d_F)
summary(sucro_mod3)
# not  converged 

anova(sucro_mod2, sucro_mod3)
# mod 2 better 

sucro_mod4 <- lmer(Mean.Speed ~ Sucrose.consumed + (1|Intertegular.distance..mm.) + (1|Mill), data = d_F)
summary(sucro_mod4)

anova(sucro_mod2, sucro_mod4)
# mod4 better and converged. 

sucro_mod5 <- lmer(Mean.Speed ~ Sucrose.consumed + (1|Intertegular.distance..mm.), data = d_F)
summary(sucro_mod5)

anova( sucro_mod4, sucro_mod5)
# mod 4 much better

sucro_mod6 <- lmer(Mean.Speed ~ Sucrose.consumed + (1|Mill), data = d_F)
summary(sucro_mod6)

anova(sucro_mod4, sucro_mod6)
# mod 4 much better

anova(sucro_mod4)

# get predicted values # 
sucro_temp <- d_F[, c("Sucrose.consumed", "Intertegular.distance..mm.","Mill")]
val <- with(d_F, seq(from = min(Sucrose.consumed), to = max(Sucrose.consumed), length.out = 100))

pp <- lapply(val, function(j) {
  sucro_temp$Sucrose.consumed <- j
  predict(sucro_mod4, newdata = sucro_temp, type = "response")
})

sapply(pp[c(1, 20, 40, 60, 80, 100)], mean)

plotdat <- t(sapply(pp, function(x) {
  c(M = mean(x), quantile(x, c(0.25, 0.75)))
}))

plotdat <- as.data.frame(cbind(plotdat, val))

colnames(plotdat) <- c("Predicted", "Lower", "Upper", "Sucrose.consumed")


ggplot(plotdat, aes(x = Sucrose.consumed, y = Predicted)) + 
  geom_ribbon(aes(ymin = Lower, ymax = Upper), alpha = 0.1) + 
  geom_line(size = 1) + ylim(c(0, 3))

# plot model 
speed_sucro_consumed70 <- ggplot() +
  geom_point(data = d_F, aes(x = Sucrose.consumed, y = Mean.Speed)) +
  geom_ribbon(data = plotdat, aes(x = Sucrose.consumed, y = Predicted, ymin = Lower, ymax = Upper), alpha = .15) +
  geom_line(data = plotdat, aes(x = Sucrose.consumed,  y = Predicted)) +
  ylab("Mean velocity (m/s)") +
  xlab("Sucrose consumed (g)") +
  ggtitle("Sucrose consumed before flight on mean speed flown") + 
  theme_minimal() +
  scale_color_npg()+
  theme(text = element_text(size=14))



#################################### MODELS  ####################################################


###### SEX ON FLIGHT INITIATION ######

### Binomial model #

Init_mod1 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + Microbiome + (1|Mill) + (1|Colony) + (1|Group.size), nAGQ = 0, family = binomial(), data = d)
summary(Init_mod1)

Init_mod2 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + Microbiome + (1|Mill) + (1|Colony), nAGQ = 0,  family = binomial, data = d)
summary(Init_mod2)

anova(Init_mod1, Init_mod2)
# reduced model 2 better 

Init_mod3 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + Microbiome + (1|Mill), nAGQ = 0,  family = binomial, data = d)
summary(Init_mod3)

anova(Init_mod2, Init_mod3)
# mod2 better 

Init_mod4 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + Microbiome + (1|Colony), nAGQ = 0, family = binomial, data = d)
summary(Init_mod4)

anova(Init_mod2, Init_mod4)
# mod4 better 

Init_mod5 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + (1|Colony), nAGQ = 0, family = binomial, data = d)
summary(Init_mod5)

anova(Init_mod4, Init_mod5)
# mod5 better 

# run normal glm with fixed factor and compare 
glm_init1 <- glm(Initiation ~ Intertegular.distance..mm. + Sex + Colony, family = binomial, data = d)
summary(glm_init1)

anova(Init_mod2, glm_init1, test = "Chisq")
# glm better fitting model 

glm_init2 <- glm(Initiation ~ Intertegular.distance..mm.*Colony + Sex, family = binomial, data = d)
summary(glm_init2)

anova(glm_init1, glm_init2, test = "Chisq")
# glm_inti1 slightly better 

# predict model values #
init_temp <- d[, c("Sex", "Intertegular.distance..mm.", "Colony")]
summary(d$Intertegular.distance..mm.)

init_vals <- with(d, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))

pred_init <- lapply(init_vals, function (j) {
  init_temp$Intertegular.distance..mm. <- j
  predict(glm_init1, newdata = init_temp, type = "response")
})

sapply(pred_init[c(1, 20, 40, 60, 80, 100)], mean) 

plot_init <- t(sapply(pred_init, function(x) {
  c(M = mean(x), quantile (x, c(0.25, 0.75)))
}))

plot_init <- as.data.frame(cbind(plot_init, init_vals))

colnames(plot_init) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")

# plot for model 
ggplot() +
  geom_line(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted)) +
  geom_point(data = d, aes(x = Intertegular.distance..mm., y = Initiation, color = Microbiome)) +
  ylim(c(0,1))

# predict for males and females 

pred_init <- lapply(levels(d$Sex), function(sex) {
  init_temp$Sex [] <- sex
  lapply(init_vals, function(j) {
    init_temp$Intertegular.distance..mm. <- j
    predict(glm_init1, newdata = init_temp, type = "response")
  })
})

# get means and quartiles for all vals for each sex
plot_init <- lapply(pred_init, function(X) {
  init_temp <- t(sapply(X, function(x) {
    c(M = mean (x), quantile(x, c(0.25, 0.75)))
  }))
  init_temp <- as.data.frame(cbind(init_temp, init_vals))
  colnames(init_temp) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")
  return(init_temp)
})

# combine to one data frame
plot_init <- do.call(rbind, plot_init)

# add sex 
plot_init$Sex <- factor(rep(levels(d$Sex), each = length(init_vals)))

head(plot_init)

# graph between male and females 
Initiation_M_F <- ggplot()+
  geom_point(data = d, aes(x = Intertegular.distance..mm., y = Initiation, color = Sex)) +
  geom_ribbon(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper, fill = Sex), alpha = 0.15) +
  geom_line(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, color = Sex), size = 1) +
  ylim(c(0,1)) +
  ylab("Probability of flight initiation") +
  xlab("Intertegular distance (mm)") +
  #ggtitle("Probability of flight initiation in male and female bees") +
  theme_minimal_grid(line_size = 0.2) +
  scale_color_manual(values = cbp1) +
  scale_fill_manual(values = cbp1) +
  theme(text = element_text(size=14)) 

scale_fill_manual(values = cbp2)

## graph between colonies 
summary(glm_init1)

# predict model values #
init_temp <- d[, c("Sex", "Intertegular.distance..mm.", "Colony")]
summary(d$Intertegular.distance..mm.)

init_vals <- with(d, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))


# predict for colonies

pred_init <- lapply(levels(d$Colony), function(col) {
  init_temp$Colony [] <- col
  lapply(init_vals, function(j) {
    init_temp$Intertegular.distance..mm. <- j
    predict(glm_init1, newdata = init_temp, type = "response")
  })
})

# get means and quartiles for all vals for each colony
plot_init <- lapply(pred_init, function(X) {
  init_temp <- t(sapply(X, function(x) {
    c(M = mean (x), quantile(x, c(0.25, 0.75)))
  }))
  init_temp <- as.data.frame(cbind(init_temp, init_vals))
  colnames(init_temp) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")
  return(init_temp)
})

# combine to one data frame
plot_init <- do.call(rbind, plot_init)

# add sex 
plot_init$Colony <- factor(rep(levels(d$Colony), each = length(init_vals)))

head(plot_init)

# plot graph
Initiation_Col <- ggplot()+
  geom_point(data = d, aes(x = Intertegular.distance..mm., y = Initiation, color = Colony)) +
  geom_ribbon(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper), alpha = 0.15) +
  geom_line(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, color = Colony), size = 1) +
  ylim(c(0,1)) +
  ylab("Probability of flight initiation") +
  xlab("Intertegular distance (mm)") +
  ggtitle("Probability of flight initiation between colonies") +
  theme_minimal_grid(line_size = 0.2) +
  scale_color_npg() +
  theme(text = element_text(size=14))


###### MICROBIOME on FLIGHT INITIATION ####

m1 <- glmer(Initiation ~ Intertegular.distance..mm. + Microbiome + (1|Mill) + (1|Colony) + (1|Group.size), nAGQ = 0, family = binomial(), data = d_Fem)
summary(m1)

m2 <- glmer(Initiation ~ Intertegular.distance..mm. +  Microbiome + (1|Mill) + (1|Colony), nAGQ = 0, family = binomial(), data = d_Fem)
summary(m2)

anova(m1, m2)
# m2 better 

m3 <- glmer(Initiation ~ Intertegular.distance..mm. +  Microbiome + (1|Colony), nAGQ = 0, family = binomial(), data = d_Fem)
summary(m3)

anova(m2, m3)
# m3 better 

m4 <- glm(Initiation ~ Intertegular.distance..mm. +  Microbiome + Colony, family = binomial(), data = d_Fem)
summary(m4)

anova(m3, m4)
# m4 better 
AIC(m3, m4)

# check dispersion
m4$deviance/m4$df.residual
#  0.9397649 ok 

#predict model values #
init_temp <- d_Fem[, c("Microbiome", "Intertegular.distance..mm.", "Colony")]
summary(d$Intertegular.distance..mm.)

init_vals <- with(d, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))

pred_init <- lapply(init_vals, function (j) {
  init_temp$Intertegular.distance..mm. <- j
  predict(m5, newdata = init_temp, type = "response")
})

sapply(pred_init[c(1, 20, 40, 60, 80, 100)], mean) 

plot_init <- t(sapply(pred_init, function(x) {
  c(M = mean(x), quantile (x, c(0.25, 0.75)))
}))

plot_init <- as.data.frame(cbind(plot_init, init_vals))

colnames(plot_init) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")

# plot for model 
ggplot() +
  geom_line(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted)) +
  geom_point(data = d_Fem, aes(x = Intertegular.distance..mm., y = Initiation, color = Microbiome)) +
  ylim(c(0,1))

# predict for microbiome presence/absence 

pred_init <- lapply(levels(d_Fem$Microbiome), function(micro) {
  init_temp$Microbiome [] <- micro
  lapply(init_vals, function(j) {
    init_temp$Intertegular.distance..mm. <- j
    predict(m5, newdata = init_temp, type = "response")
  })
})

# get means and quartiles for all vals for each sex
plot_init <- lapply(pred_init, function(X) {
  init_temp <- t(sapply(X, function(x) {
    c(M = mean (x), quantile(x, c(0.25, 0.75)))
  }))
  init_temp <- as.data.frame(cbind(init_temp, init_vals))
  colnames(init_temp) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")
  return(init_temp)
})

# combine to one data frame
plot_init <- do.call(rbind, plot_init)

# add microbiome 
plot_init$Microbiome <- factor(rep(levels(d_Fem$Microbiome), each = length(init_vals)))

head(plot_init)

# string plot title 
title <- expression(paste("Probability of flight initiation between female worker GM"["1"], " and GM"["0"]))

Initiation_treatment_Females <- ggplot()+
  geom_point(data = d_Fem, aes(x = Intertegular.distance..mm., y = Initiation, color = Microbiome)) +
  geom_ribbon(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper, fill = Microbiome), alpha = 0.15, show.legend = FALSE) +
  geom_line(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, color = Microbiome), size = 1) +
  ylim(c(0,1)) +
  ylab("Probability of flight initiation") +
  xlab("Intertegular distance (mm)") +
  ggtitle(title) +
  theme_minimal()+
  scale_color_manual(values = cbp2, labels = expression("GM"["0"], "GM"["1"]))+
  theme(text = element_text(size=14)) 



##### Colony & flight initiation #####

### Binomial model ###

Col_m1 <- glmer(Initiation ~ Colony + Mean.Speed + (1|Intertegular.distance..mm.) + Sex + Microbiome + (1|Mill) + (1|Group.size), nAGQ = 0, family = binomial(), data = d)
summary(Col_m1)

Col_m2 <- glmer(Initiation ~ Colony*(1|Intertegular.distance..mm.) + Mean.Speed + Sex + Microbiome + (1|Mill) + (1|Group.size), nAGQ = 0, family = binomial(), data = d)
summary(Col_m2)

anova(Col_m1, Col_m2)
#the same 

Col_m3 <- glmer(Initiation ~ Colony + (1|Intertegular.distance..mm.) + Mean.Speed + Sex + (1|Mill) + (1|Group.size), nAGQ = 0, family = binomial(), data = d)
summary(Col_m3)

anova(Col_m1, Col_m3)
# Col_m3 better

Col_m4 <- glmer(Initiation ~ Colony + (1|Intertegular.distance..mm.) + Mean.Speed + Sex + (1|Mill), nAGQ = 0, family = binomial(), data = d)
summary(Col_m4)

anova(Col_m3, Col_m4)
# m4 better 

Col_m5 <- glmer(Initiation ~ Colony + (1|Intertegular.distance..mm.) + Mean.Speed + Sex, nAGQ = 0, family = binomial(), data = d)
summary(Col_m5)

anova(Col_m4, Col_m5, test = "Chisq")
# m5 better 

Col_m6 <- glm(Initiation ~ Colony + Intertegular.distance..mm. + Mean.Speed +  Sex, family = binomial(), data = d)
summary(Col_m6)

anova(Col_m5, Col_m6, test = "Chisq")
# m6 better

Col_m7 <- glm(Initiation ~ Colony + Mean.Speed +  Sex, family = binomial(), data = d)
summary(Col_m7)

anova(Col_m6, Col_m7, test = "Chisq")

# predict model values #
pred <- expand.grid(Mean.Speed = rep(seq(from = min(d$Mean.Speed), to = max(d$Mean.Speed), length.out = 100), times = 10))
pred$Colony <- factor(rep(c("C12", "C13", "C14", "C15", "C16"), each = 100, times = 2))
pred$Sex <- factor(rep(c("M", "F"), each = 100, times = 5))

premod <- predict(Col_m7, newdata = pred, type = "response", se.fit = T)
pred$fit <- premod$fit
pred$se.fit <- premod$sefit
pred$confint <- premod$se.fit * qt(0.975, df = Col_m7$df.residual)
pred$LL <- (pred$fit - pred$confint)
pred$UL <- (pred$fit + pred$confint)

pred_C12 <- filter(pred, Colony == "C12")
pred_C12M <- filter(pred_C12, Sex == "M")
pred_C12F <- filter(pred_C12, Sex == "F")
pred_C13 <- filter(pred, Colony == "C13")
pred_C13M <- filter(pred_C13, Sex == "M")
pred_C13F <- filter(pred_C13, Sex == "F")
pred_C14 <- filter(pred, Colony == "C14")
pred_C14M <- filter(pred_C14, Sex == "M")
pred_C14F <- filter(pred_C14, Sex == "F")
pred_C15 <- filter(pred, Colony == "C15")
pred_C15M <- filter(pred_C15, Sex == "M")
pred_C15F <- filter(pred_C15, Sex == "F")
pred_C16 <- filter(pred, Colony == "C16")
pred_C16M <- filter(pred_C16, Sex == "M")
pred_C16F <- filter(pred_C16, Sex == "F")

C12 <- filter(d, Colony == "C12")
C13 <- filter(d, Colony == "C13")
C14 <- filter(d, Colony == "C14")
C15 <- filter(d, Colony == "C15")
C16 <- filter(d, Colony == "C16")

colony_plots <- ggplot() +
  geom_point(data = d, aes(x = Mean.Speed, y = Initiation, color = Sex)) + 
  geom_line(data = pred_C12M, aes(x = Mean.Speed, y = fit, color = Sex)) + 
  geom_line(data = pred_C12F, aes(x = Mean.Speed, y = fit, color = Sex)) +
  geom_line(data = pred_C13M, aes(x = Mean.Speed, y = fit, color = Sex)) + 
  geom_line(data = pred_C13F, aes(x = Mean.Speed, y = fit, color = Sex)) +
  geom_line(data = pred_C14F, aes(x = Mean.Speed, y = fit, color = Sex)) +
  geom_line(data = pred_C15F, aes(x = Mean.Speed, y = fit, color = Sex)) + 
  geom_line(data = pred_C16F, aes(x = Mean.Speed, y = fit, color = Sex)) +
  ylab("Probability of flight initiation") +
  xlab("Mean speed (m/s)") +
  ggtitle("Colony on probability of flight initiation in male and female bees") +
  theme_minimal_grid() +
  scale_color_npg()

colony_plots <- colony_plots + facet_wrap(~ Colony, ncol = 5)


############# FLIGHT MODELS  ##############

#########  1)        All FEMALE bees which underwent a flight trial #########
# filter bees to remove bees which flew >500m as insufficient data points at high distances
d1 <- filter(d_Fem, Distance..m. <= 500)

# scatter plot 
ggplot() +
  geom_point(data = d1, aes(x = Distance..m., y = Microbiome)) 

# binomial glm model 
mod1 <- glmer(Microbiome ~ Distance..m. + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), family = binomial, data = d1)
summary(mod1)

mod2 <- glmer(Microbiome ~ Distance..m. + (1|Intertegular.distance..mm.) + (1|Colony), family = binomial, data = d1)
summary(mod2)

anova(mod1, mod2)
# mod2 better 

mod3 <- glmer(Microbiome ~ Distance..m. + (1|Intertegular.distance..mm.), family = binomial, data = d1)
summary(mod3)

anova(mod2, mod3)
# mod3 better 

mod4 <- glm(Microbiome ~ Distance..m. + Intertegular.distance..mm., family = binomial, data = d1)
summary(mod4)

anova(mod3, mod4)
# glm mod4 better 

# check dispersion
mod4$deviance/mod4$df.residual
# 1.353794

mod5 <- glm(Microbiome ~ Distance..m., family = binomial, data = d1)
summary(mod5)
# mod5 best 

#check dispersion
mod5$deviance/mod5$df.residual
# 1.344497

# get predict values
pred <- expand.grid(Distance..m. = seq(from = min(d1$Distance..m.), to = max(d1$Distance..m.), length.out = 100))

pred_mod <- predict(mod5, newdata=pred, se.fit=TRUE)
pred$fit <- pred_mod$fit
pred$se.fit <- pred_mod$sefit
pred$confint <- pred_mod$se.fit * qt(0.975, df=mod5$df.residual)
pred$LL <- pred$fit - pred$confint
pred$UL <- pred$fit + pred$confint

all_females_plot <- ggplot()+
  geom_line(data = pred, aes(x = Distance..m., y = fit)) +
  geom_ribbon(data = pred, aes(x = Distance..m., y = fit, ymin = LL, ymax = UL), alpha = 0.2) +
  geom_abline(intercept = 1, slope = 0, linetype = "dashed") +
  geom_abline(intercept = 0, slope = 0, linetype = "dashed") +
  ylab("Probability of microbiome presence/absence") +
  xlab("Distance (m)") +
  ggtitle("Probabilty of gut microbiome presence by distance flown")+
  xlim(0, 450) +
  theme_classic()+
  scale_color_npg()

# very large confidence intervals 
#########  2)        MALES & FEMALES which initated flight  (flew > 70m) ##########

mod1 <- glmer(Distance..m. ~ Microbiome + Sex + Mean.Speed + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(mod1)

mod2 <- glmer(Distance..m. ~ Microbiome + Sex + Mean.Speed + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ =0,  
              family = Gamma(link = log),data = d_F)
summary(mod2)

anova(mod1, mod2)
# mod2 slightly better

mod3 <- glmer(Distance..m. ~ Microbiome + Sex + Mean.Speed + (1|Intertegular.distance..mm.), nAGQ = 0, family = Gamma(link = log), data = d_F)
summary(mod3)

anova(mod2, mod3)
# mod2 better 

mod4 <- glmer(Distance..m. ~  Microbiome + Sex + Mean.Speed + (1|Colony), nAGQ =0, family = Gamma(link = log), data = d_F)
summary(mod4)

anova(mod2, mod4)
# mod2 better

# remove sex as not significant 
mod5 <- glmer(Distance..m. ~ Microbiome + Mean.Speed + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ =0,  
              family = Gamma(link = log),data = d_F)

summary(mod5)

anova(mod2, mod5)
# mod5 better 


# scatter plot size vs distance 
ggplot(d_F, aes(x = Mean.Speed, y = Distance..m.)) + 
  geom_point( aes(color = Microbiome)) +
  xlab("Mean speed (s)") + 
  ylab("Distance flown (m)")

#  Predict model values #
Ftemp <- d_F[ , c("Mean.Speed", "Microbiome", "Intertegular.distance..mm.", "Colony")]
summary(Ftemp$Mean.Speed)  

Fvals <- with(d_F, seq(from = min(Mean.Speed), to = max(Mean.Speed), length.out = 100))

pp <- lapply(Fvals, function(j) {
  Ftemp$Mean.Speed <- j
  predict(mod5, newdata = Ftemp, type = "response")
})


# predicted values
pred_biome_F <- lapply(levels(d_F$Microbiome), function(presence) {
  Ftemp$Microbiome[] <- presence
  lapply(Fvals, function (j) {
    Ftemp$Mean.Speed <- j
    predict(mod5, newdata = Ftemp, type = "response")
  })
})


# get means and quartiles for all Fvals for each level Microbiome
plotdat2_F <- lapply(pred_biome_F, function(X) {
  Ftemp <- t(sapply(X, function(x) {
    c(M=mean(x), quantile(x, c(0.25, 0.75)))
  }))
  Ftemp <- as.data.frame(cbind(Ftemp, Fvals))
  colnames(Ftemp) <- c("Predicted", "Lower", "Upper", "Mean.Speed")
  return(Ftemp)
})

# combine to one data frame
plotdat2_F <- do.call(rbind, plotdat2_F)

# add microbiome levels
plotdat2_F$Microbiome <- factor(rep(levels(d_FF$Microbiome), each = length(Fvals)))

# plot 
title <- expression(paste("Distance flown in GM"["1"], " and GM"["0"], " bees which initiated flight"))

all_bees_70_plot <- ggplot() + 
  geom_point(data = d_F, aes(x = Mean.Speed, y = Distance..m., color = Microbiome)) +
  geom_line(data = plotdat2_F, aes(x = Mean.Speed, y = Predicted, color = Microbiome)) +
  geom_ribbon(data = plotdat2_F, aes(x = Mean.Speed, y = Predicted, ymin = Lower, ymax = Upper, fill = Microbiome), alpha = 0.1, show.legend = FALSE) +
  xlab("Mean speed (m/s)") + 
  ylab("Distance (m)")+ 
  ggtitle(title)  +
  theme_minimal_grid(line_size = 0.2) +
  scale_color_npg(labels = expression("GM"["0"], "GM"["1"]))+
  theme(text = element_text(size=14)) 

#########  3)        FEMALE bees which initiated flight only #######

# model 1 
Fmod1 <- glmer(Distance..m. ~ (1|Intertegular.distance..mm.) + Mean.Speed + Weight + Microbiome + (1|Mill) + (1|Colony) + (1|Group.size), nAGQ =0,
               family = Gamma(link = log),data = d_FF)
summary(Fmod1)

Fmod2 <- glmer(Distance..m. ~ (1|Intertegular.distance..mm.) + Mean.Speed + Weight + Microbiome + (1|Mill) + (1|Colony), nAGQ =0,
               family = Gamma(link = log),data = d_FF)
summary(Fmod2)

anova(Fmod1, Fmod2)
# Fmod2 better 

Fmod3 <- glmer(Distance..m. ~ (1|Intertegular.distance..mm.) + Mean.Speed + Weight + Microbiome + (1|Colony), nAGQ =0,
               family = Gamma(link = log),data = d_FF)
summary(Fmod3)

anova(Fmod2, Fmod3)
# Fmod2 better

Fmod4 <- glmer(Distance..m. ~ (1|Intertegular.distance..mm.) + Mean.Speed + Weight + Microbiome  + (1|Mill), nAGQ =0,
               family = Gamma(link = log),data = d_FF)
summary(Fmod4)

anova(Fmod2, Fmod4)
# Fmod2 better 

Fmod5 <- glmer(Distance..m. ~ (1|Intertegular.distance..mm.) + Mean.Speed + Microbiome + (1|Mill) + (1|Colony), nAGQ =0,
               family = Gamma(link = log),data = d_FF)
summary(Fmod5)

anova(Fmod2, Fmod5)
# Fmod5 better 

# scatter plot 
# mean speed vs distance
ggplot(d_FF, aes(x = Mean.Speed, y = Distance..m.)) + 
  geom_point(aes(color = Microbiome)) +
  xlab("Mean speed (s)") + 
  ylab("Distance flown (m)")

# predict GLM model values #

print(Fmod5, corr = FALSE)

se <- sqrt(diag(vcov(Fmod5)))
# table of estimates with 95% CI
(table <- cbind(Est = fixef(Fmod5), LL = fixef(Fmod5) - 1.96 * se, UL = fixef(Fmod5) + 1.96 *
                  se))

## mean speed vs distance ##
Ftemp <- d_FF[ , c("Mean.Speed", "Mill", "Microbiome", "Intertegular.distance..mm.", "Colony")]
summary(Ftemp$Mean.Speed)  

Fvals <- with(d_FF, seq(from = min(Mean.Speed), to = max(Mean.Speed), length.out = 100))

pp <- lapply(Fvals, function(j) {
  Ftemp$Mean.Speed <- j
  predict(Fmod5, newdata = Ftemp, type = "response")
})


# predicted values
pred_biome_F <- lapply(levels(d_FF$Microbiome), function(presence) {
  Ftemp$Microbiome[] <- presence
  lapply(Fvals, function (j) {
    Ftemp$Mean.Speed <- j
    predict(Fmod5, newdata = Ftemp, type = "response")
  })
})

# get means and quartiles for all Fvals for each level Microbiome
plotdat2_F <- lapply(pred_biome_F, function(X) {
  Ftemp <- t(sapply(X, function(x) {
    c(M=mean(x), quantile(x, c(0.25, 0.75)))
  }))
  Ftemp <- as.data.frame(cbind(Ftemp, Fvals))
  colnames(Ftemp) <- c("Predicted", "Lower", "Upper", "Mean.Speed")
  return(Ftemp)
})

# combine to one data frame
plotdat2_F <- do.call(rbind, plotdat2_F)

# add microbiome levels
plotdat2_F$Microbiome <- factor(rep(levels(d_FF$Microbiome), each = length(Fvals)))

# plot mean speed vs distance
title <- expression(paste("Mean velocity of distance flown in GM"["1"], " and GM"["0"], " female worker bees which initiated flight"))

F_speed_GLM <- ggplot() +
  geom_point(data = d_FF, aes(x = Mean.Speed, y = Distance..m., color = Microbiome)) +
  #geom_ribbon(data = plotdat2_F, aes(x = Mean.Speed, y = Predicted, ymin = Lower, ymax = Upper, fill = Microbiome), alpha = 0.2, show.legend = FALSE) +
  geom_line(data = plotdat2_F, aes(x = Mean.Speed, y = Predicted, colour = Microbiome), size = 0.75) +
  ylim(c(0, 1700)) +
  ylab("Distance (m)") +
  xlab("Mean velocity (m/s)") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  scale_color_manual(values = cbp2, labels = expression("GM"["0"], "GM"["1"]))+
  theme(text = element_text(size=14)) 


#########  4)        MALES & FEMALES without microbiome ####
# no male microbiome bees which flew

GF_mod1 <- glmer(Distance..m. ~  Sex + (1|Intertegular.distance..mm.) + Mean.Speed + (1|Mill) + (1|Colony) + (1|Group.size), nAGQ = 0, 
                 family = Gamma(link = log),data = GF_d_F)

summary(GF_mod1)

# is size important?
GF_mod2 <- glmer(Distance..m. ~ Sex + Mean.Speed + (1|Intertegular.distance..mm.) + (1|Mill) + (1|Colony), nAGQ = 0, family = Gamma(link = log), data = GF_d_F)
summary(GF_mod2)

anova(GF_mod1, GF_mod2)
# model 2 is better 

# is speed important? 
GF_mod3 <- glmer(Distance..m. ~ Sex + Mean.Speed + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ = 0, family = Gamma(link = log), data = GF_d_F)
summary(GF_mod3) 

lrtest(GF_mod2, GF_mod3)
# model 2 is better

GF_mod4 <- glmer(Distance..m. ~ Sex + Mean.Speed + (1|Intertegular.distance..mm.) + (1|Mill), nAGQ = 0, family = Gamma(link = log), data = GF_d_F)
summary(GF_mod4)

lrtest(GF_mod2, GF_mod4)
# mod2 better 

GF_mod5 <- glmer(Distance..m. ~ Sex + Mean.Speed + (1|Mill) + (1|Colony), nAGQ = 0, family = Gamma(link = log), data = GF_d_F)
summary(GF_mod5)

lrtest(GF_mod2, GF_mod5)
# model 2 better

plot(GF_mod2)

# get predicted values

pred <- expand.grid(Mean.Speed = rep(seq(from = min(GF_d_F$Mean.Speed), to = max(GF_d_F$Mean.Speed), length.out = 100), times = 30))
pred$Sex <- factor(rep(c("M", "F"), each = 100, times = 15))
pred$Intertegular.distance..mm. <- rep(mean(GF_d_F$Intertegular.distance..mm.), each = 100, times = 30)
pred$Mill <- factor(rep(1:6, each = 100, times = 5))
pred$Colony <- factor(rep(c("C12", "C13", "C14", "C15", "C16"), each = 100, times = 6))

pred$fit <- predict(GF_mod2, newdata = pred, type = "response", se.fit = TRUE)

GF_temp <- GF_d_F[ , c("Intertegular.distance..mm.", "Sex", "Mean.Speed", "Mill", "Colony")]
summary(GF_temp$Mean.Speed)

GFvals <- with(GF_d_F, seq(from = min(Mean.Speed), to = max(Mean.Speed), length.out = 100))

# predicted values
pred_GF <- lapply(levels(GF_d_F$Sex), function(i) {
  GF_temp$Sex[] <- i
  lapply(GFvals, function (j) {
    GF_temp$Mean.Speed <- j
    predict(GF_mod2, newdata = GF_temp, type = "response")
  })
})

# get means and quartiles for all Fvals for each level Microbiome
plotdat_GF <- lapply(pred_GF, function(X) {
  GF_temp <- t(sapply(X, function(x) {
    c(M=mean(x), quantile(x, c(0.25, 0.75)))
  }))
  GF_temp <- as.data.frame(cbind(GF_temp, GFvals))
  colnames(GF_temp) <- c("PredictedMean", "Lower", "Upper", "Mean.Speed")
  return(GF_temp)
})

# combine to one data frame
plotdat_GF <- do.call(rbind, plotdat_GF)

# add microbiome levels
plotdat_GF$Sex <- factor(rep(levels(GF_d_F$Sex), each = length(GFvals)))

# plot mean speed vs distance 
#title <- expression(paste("Female and male microbiome absent (GM"["0"], ") bees which initiated flight"))

GF_plot1 <- ggplot() +
  geom_point(data = GF_d_F, aes(x = Mean.Speed, y = Distance..m., color = Sex)) +
  geom_ribbon(data = plotdat_GF, aes(x = Mean.Speed, y = PredictedMean, ymin = Lower, ymax = Upper, fill = Sex), alpha = 0.2) +
  geom_line(data = plotdat_GF, aes(x = Mean.Speed, y = PredictedMean, colour = Sex), size = 0.75) +
  ylim(c(0, 2000)) +
  ylab("Distance (m)") +
  xlab("Mean velocity (m/s)") +
  ggtitle("a)") + 
  theme_classic() +
  theme(legend.position = "none")+
  scale_color_manual(values = cbp1)+
  scale_fill_manual(values = cbp1) +
  theme(text = element_text(size=14)) 



#########  5)        MICROBIOME ON MEAN SPEED OF FLIGHT - Females which initiated flight ###########

ggplot(d_FF, aes(x = Mean.Speed)) + 
  geom_histogram(binwidth = 0.1)
# bimodal distribution

mean(d_FF$Mean.Speed)
median(d_FF$Mean.Speed)

ggplot() +
  geom_point(data = d_FF, aes(x = Intertegular.distance..mm., y  = Mean.Speed, color =  Microbiome))

mod1 <- lmer(Mean.Speed ~ Intertegular.distance..mm. + Microbiome + (1|Colony) + (1|Mill) , data = d_FF)
summary(mod1)

plot(mod1)
anova(mod1)


## predicted values distance ##
temp <- d_FF[ , c("Microbiome", "Intertegular.distance..mm.", "Colony")]
summary(temp$Intertegular.distance..mm.)  

vals <- with(d_FF, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))

pp <- lapply(vals, function(j) {
  temp$Intertegular.distance..mm. <- j
  predict(mod1, newdata = temp, type = "response")
})


# predicted values
pred_micro <- lapply(levels(d_FF$Microbiome), function(micro) {
  temp$Microbiome[] <- micro
  lapply(vals, function (j) {
    temp$Intertegular.distance..mm. <- j
    predict(mod1, newdata = temp, type = "response")
  })
})

# get means and quartiles for all Fvals for each level Microbiome
plotdat <- lapply(pred_micro, function(X) {
  temp <- t(sapply(X, function(x) {
    c(M=mean(x), quantile(x, c(0.25, 0.75)))
  }))
  temp <- as.data.frame(cbind(temp, vals))
  colnames(temp) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")
  return(temp)
})

# combine to one data frame
plotdat <- do.call(rbind, plotdat)

# add microbiome levels
plotdat$Microbiome<- factor(rep(levels(d_FF$Microbiome), each = length(vals)))

# plot mean speed vs distance

speed_treat_F70 <- ggplot() +
  geom_point(data = d_FF, aes(x = Intertegular.distance..mm., y = Mean.Speed, color = Microbiome)) +
  geom_ribbon(data = plotdat, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper, fill = Microbiome), alpha = 0.2, show.legend = FALSE) +
  geom_line(data = plotdat, aes(x = Intertegular.distance..mm., y = Predicted, colour = Microbiome)) +
  ylim(c(0, 2)) +
  ylab("Mean velocity (m/s)") +
  xlab("Intertegular distance (mm)") +
  theme_classic() +
  scale_fill_manual(values = cbp2) +
  scale_color_manual(values = cbp2, labels = expression("GM"["0"], "GM"["1"]))+
  theme(text = element_text(size=14)) 



#########  6)        GM0 MALES & FEMALES (which initiated flight) ON MEAN SPEED OF FLIGHT ######
ggplot(GF_d_F, aes(x =  Mean.Speed))+
  geom_histogram(binwidth = 0.1)
# right skewed 

ggplot() +
  geom_point(data = GF_d_F, aes(x = Intertegular.distance..mm., y  = Mean.Speed, color = Sex))

# model 
mod1 <- glmer(Mean.Speed ~ Intertegular.distance..mm. + Sex + (1|Colony) + (1|Mill) + (1|Group.size), nAGQ = 0, family = Gamma(link = log), data = GF_d_F)
summary(mod1)

plot(mod1)
# starry nightw

## predicted values distance ##
temp <- GF_d_F[ , c("Group.size", "Mill", "Sex", "Intertegular.distance..mm.", "Colony")]
summary(temp$Intertegular.distance..mm.)  

vals <- with(d_FF, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))

pp <- lapply(vals, function(j) {
  temp$Intertegular.distance..mm. <- j
  predict(mod1, newdata = temp, type = "response")
})


# predicted values
pred_sex <- lapply(levels(GF_d_F$Sex), function(sex) {
  temp$Sex[] <- sex
  lapply(vals, function (j) {
    temp$Intertegular.distance..mm. <- j
    predict(mod1, newdata = temp, type = "response")
  })
})

# get means and quartiles for all Fvals for each level Microbiome
plotdat <- lapply(pred_sex, function(X) {
  temp <- t(sapply(X, function(x) {
    c(M=mean(x), quantile(x, c(0.25, 0.75)))
  }))
  temp <- as.data.frame(cbind(temp, vals))
  colnames(temp) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")
  return(temp)
})

# combine to one data frame
plotdat <- do.call(rbind, plotdat)

# add microbiome levels
plotdat$Sex <- factor(rep(levels(GF_d_F$Sex), each = length(vals)))

# plot mean speed vs distance
#title <- expression(paste("Intertegular distance on mean velocity flown in GM"["0"], " male and female bees which initiated flight"))

speed_sex <- ggplot() +
  geom_point(data = GF_d_F, aes(x = Intertegular.distance..mm., y = Mean.Speed, color = Sex)) +
  geom_ribbon(data = plotdat, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper, fill = Sex), alpha = 0.2) +
  geom_line(data = plotdat, aes(x = Intertegular.distance..mm., y = Predicted, colour = Sex), size = 0.75) +
  ylim(c(0, 2)) +
  ylab("Mean velocity (m/s)") +
  xlab("Intertegular distance (mm)") +
  ggtitle("b)")+ 
  theme_classic() +
  scale_fill_manual(values = cbp1) +
  scale_color_manual(values = cbp1)+
  theme(text = element_text(size=14)) 


# combine GF_mod1 plot and speed_sex plot 

GM0_MF_plots <- plot_grid(GF_plot1, speed_sex)

##### SAVE PLOTS #### ######

ggsave("GM0_MF_plots.png", plot = GM0_MF_plots, device = "png", width = 30, height = 15, units = "cm")
ggsave("All_F_data_plot.png", plot = all_females_plot, device = "png")
ggsave("Colony_initiation_plots.png", plot = colony_plots, device = "png", width = 20, height = 15, units = "cm")
ggsave("sucro_init_plot.png", plot = sucro_init_plot, device = "png", width = 20, height = 15, units = "cm")
ggsave("sucrose_consumed70_model.png", plot = sucro_consumed70, device = "png", width = 15, height = 15, units = "cm")
ggsave("sucrose_70_speed.png", plot =  speed_sucro_consumed70, device = "png", width = 18, height = 15, units = "cm" )
ggsave("sucro_dist.png", plot  = sucro_dist, device = "png",  width = 20, height = 15, units = "cm")
ggsave("Male_female_initiation.png", plot = Initiation_M_F, device = "png", width = 18, height = 15, units = "cm")
ggsave("Treatment_initiation_F.png", plot = Initiation_treatment_Females, device = "png", width = 20, height = 15, units = "cm")
ggsave("Treatment_dist_allbees70.png", plot = all_bees_70_plot, device = "png", width = 17, height = 15, units = "cm")
ggsave("Females70_dist_speed.png", plot = F_speed_GLM, device = "png", width = 18, height = 15, units = "cm")
ggsave("Initiation_colonies.png", plot = Initiation_Col, device = "png", width = 18, height = 15, units = "cm")
ggsave("mean_speed_treat_females70.png", plot = speed_treat_F70 , device = "png", width = 20, height = 15, units = "cm")

# boxplots 
ggsave("speed_dist_bp_MG_GF70.png", plot = speed_dist_bp_MF_GF70, device = "png", width = 25, height = 20, units = "cm")
ggsave("speed_dist_bp_70.png", plot = speed_dist_bp_MF70, device = "png", width = 23, height =14, units = "cm")
ggsave("speed_dist_bp_microbiome70.png", plot = speed_dist_bp_microbiome70, device = "png", width = 25, height =14, units = "cm")
ggsave("speed_dist_bp_microbiomeF70.png", plot = speed_dist_bp_microbiome_F70, device = "png", width = 25, height =16, units = "cm")
ggsave("colony_dist_speed70.png", plot = speed_dist_bp_colony_70, device = "png", width = 28, height =16, units = "cm")
ggsave("speed_dist_bp_allbees_microbiome.png", plot = speed_dist_bp_treat, device = "png", width = 26, height = 16, units = "cm")
ggsave("speed_dist_bp_females_micro.png", plot = speed_dist_bp_microbiome_Fem, device = "png", width = 25, height = 16, units = "cm")
################## COLONY-DERIVED BEE ANALYSES ###################

###### boxplots ######

# sex on distance flown 
dist_bp_CD <- ggplot()+
  geom_boxplot(data = d_C, aes(x = Sex, y = Distance..m., fill = Sex))+
  geom_jitter(data = d_C, aes(x = Sex, y = Distance..m.), shape = 4) +
  ylab("Distance (m)") +
  xlab("Sex") +
  ggtitle("a) Distance flown in male and female\ncolony-derived bees") +
  theme_minimal_hgrid()+
  scale_fill_npg() +
  theme(legend.position = "none") +
  theme(text = element_text(size=14)) 

wilcox.test(d_C$Distance..m. ~ d_C$Sex)
# p-value = 0.2145 - accept null - same distribution

# sex on mean speed flown
speed_bp_CD <- ggplot()+
  geom_boxplot(data = d_C, aes(x = Sex, y = Mean.Speed, fill = Sex))+
  geom_jitter(data = d_C, aes(x = Sex, y = Mean.Speed), shape = 4) +
  ylab("Mean velocity (m/s)") +
  xlab("Sex") +
  ggtitle("b) Mean velocity of flight in male and female\ncolony-derived bees") +
  theme_minimal_hgrid()+
  scale_fill_npg() +
  theme(legend.position = "none") +
  theme(text = element_text(size=14)) 

wilcox.test(d_C$Mean.Speed ~ d_C$Sex)
# p-value = 0.9746 - accept null - same distribution

# combine boxplots 
dist_speed_bp_CD <- plot_grid(dist_bp_CD, speed_bp_CD)

# get means and medians for each sex 
aggregate(d_C[, 17:18], list(d_C$Sex), FUN = mean)
aggregate(d_C[, 17:18], list(d_C$Sex), FUN = median)


# save plot 
ggsave("dist_speed_bp_CD.png", plot = dist_speed_bp_CD, device= "png", width = 30, height = 18, units = "cm")


# bees which initiated flight

# sex on distance flown 
dist_bp_CD70 <- ggplot()+
  geom_boxplot(data = d_CF, aes(x = Sex, y = Distance..m., fill = Sex))+
  geom_jitter(data = d_CF, aes(x = Sex, y = Distance..m.), shape = 4) +
  ylab("Distance (m)") +
  xlab("Sex") +
  ggtitle("a) Distance flown in male and female colony-derived\nbees which initiated flight") +
  theme_minimal_hgrid() +
  scale_fill_npg() +
  theme(legend.position = "none") +
  theme(text = element_text(size=14)) 

wilcox.test(d_CF$Distance..m. ~ d_CF$Sex)
# p-value = 0.06044 - accept null - same distribution

# sex on mean speed flown
speed_bp_CD70 <- ggplot()+
  geom_boxplot(data = d_CF, aes(x = Sex, y = Mean.Speed, fill = Sex))+
  geom_jitter(data = d_CF, aes(x = Sex, y = Mean.Speed), shape = 4) +
  ylab("Mean speed (m/s)") +
  xlab("Sex") +
  ggtitle("b) Mean speed of flight in male and female colony-derived\nbees which initiated flight") +
  theme_minimal_hgrid() +
  scale_fill_npg() +
  theme(legend.position = "none") +
  theme(text = element_text(size=14)) 

wilcox.test(d_CF$Mean.Speed ~ d_CF$Sex)
# W = 11, p-value = 0.456  accept null - same distribution

# combine plots 
dist_speed_bp_CD70 <- plot_grid(dist_bp_CD70, speed_bp_CD70)

# save plot 
ggsave("dist_speed_bp_CD70.png", plot = dist_speed_bp_CD70, device= "png", width = 35, height = 18, units = "cm")

###### Flight initiation ##### ######

d_C$Initiation[d_C$Distance..m. <=70] <- 0
d_C$Initiation[d_C$Distance..m. >70] <- 1

ggplot(data = d_C, aes(x = Intertegular.distance..mm., y = Initiation)) +
  geom_point(aes(color = Sex))

### Binomial model #

Init_C_mod1 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + (1|Mill) + (1|Colony) + (1|Group.size), nAGQ= 0,  family = binomial(), data = d_C)
summary(Init_C_mod1)

Init_C_mod2 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + (1|Mill) + (1|Colony), nAGQ= 0, family = binomial(), data = d_C)
summary(Init_C_mod2)

anova(Init_C_mod1, Init_C_mod2)
# mod 2 better 

Init_C_mod3 <- glmer(Initiation ~ Intertegular.distance..mm. + Sex + (1|Mill), nAGQ= 0, family = binomial(), data = d_C)
summary(Init_C_mod3)

anova(Init_C_mod2, Init_C_mod3)
# mod 3 better 

Init_C_mod4 <- glmer(Initiation ~ Sex + (1|Mill), nAGQ= 0, family = binomial(), data = d_C)
summary(Init_C_mod4)

anova(Init_C_mod3, Init_C_mod4)
# mod 4 better 

Init_C_mod5 <- glmer(Initiation ~ Intertegular.distance..mm.  + (1|Mill), nAGQ= 0, family = binomial(), data = d_C)
summary(Init_C_mod5)

anova(Init_C_mod4,Init_C_mod5 )
# mod 5 better

Init_C_mod6 <- glmer(Initiation ~ Intertegular.distance..mm. + (1|Mill), nAGQ= 0, family = binomial(), data = d_C)
summary(Init_C_mod6)

# mod5 best

# predict model values #

init_temp <- d_C[, c("Sex", "Intertegular.distance..mm.", "Mill")]
summary(d_C$Intertegular.distance..mm.)

init_vals <- with(d_C, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))

pred_init <- lapply(init_vals, function (j) {
  init_temp$Intertegular.distance..mm. <- j
  predict(Init_C_mod5, newdata = init_temp, type = "response")
})

sapply(pred_init[c(1, 20, 40, 60, 80, 100)], mean) 

plot_init <- t(sapply(pred_init, function(x) {
  c(M = mean(x), quantile (x, c(0.25, 0.75)))
}))

plot_init <- as.data.frame(cbind(plot_init, init_vals))

colnames(plot_init) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")

# plot for model 
Initiation_colonybees_MF <- ggplot() +
  geom_line(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, color = "brown1")) +
  geom_ribbon(data = plot_init, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper, fill = "brown1"), alpha = 0.15)+
  geom_point(data = d_C, aes(x = Intertegular.distance..mm., y = Initiation, color = "brown1" )) +
  ylim(c(0,1)) +
  ylab("Probability of flight initiation") +
  xlab("Intertegular distance (mm)") +
  ggtitle("Probability of flight initiation in colony-derived bees") +
  theme_bw() +
  scale_color_npg() +
  scale_fill_npg() +
  theme(legend.position = "none")  +
  theme(text = element_text(size=14)) 

ggsave("Initiation_colonybees_MF.png", plot = Initiation_colonybees_MF, device = "png", width = 18, height = 15, units = "cm")

##### Colony-derived bees which INITIATED flight##### 

d_CF <- filter(d_C, Initiation == 1)

ggplot()+
  geom_point(data = d_CF, aes(x = Mean.Speed, y = Distance..m., color = Sex))

mean(d_CF$Mean.Speed)
# 0.6154672

mean(d_F$Mean.Speed) 
# 0.6343641

m1 <- glmer(Distance..m. ~ Mean.Speed + (1|Intertegular.distance..mm.) + (1|Colony) + (1|Mill), nAGQ= 0, family = Gamma(link = log), data = d_CF)
summary(m1)

m2 <- glmer(Distance..m. ~ Mean.Speed + (1|Intertegular.distance..mm.) + (1|Colony), nAGQ = 0,  family = Gamma(link = log), data = d_CF)
summary(m2)

anova(m1, m2)
# m2 better

m3 <- glmer(Distance..m. ~ Mean.Speed + (1|Intertegular.distance..mm.), nAGQ = 0,  family = Gamma(link = log), data = d_CF)
summary(m3)

#anova(m2,m3)
# m3 better 

glm1 <- glm(Distance..m. ~ Mean.Speed + Intertegular.distance..mm., family = Gamma(link = log), data = d_CF)
summary(glm1)

anova(m3, glm1)
#m3 much better

# predict model values #

temp <- d_CF[, c("Mean.Speed", "Intertegular.distance..mm.")]
summary(d_CF$Mean.Speed)

init_vals <- with(d_CF, seq(from = min(Mean.Speed), to = max(Mean.Speed), length.out = 100))

pred_init <- lapply(init_vals, function (j) {
  temp$Mean.Speed <- j
  predict(m3, newdata = temp, type = "response")
})

sapply(pred_init[c(1, 20, 40, 60, 80, 100)], mean) 

plot_init <- t(sapply(pred_init, function(x) {
  c(M = mean(x), quantile (x, c(0.25, 0.75)))
}))

plot_init <- as.data.frame(cbind(plot_init, init_vals))

colnames(plot_init) <- c("Predicted", "Lower", "Upper", "Mean.Speed")

# plot for model 
Colonybees_flight_plot <- ggplot() +
  geom_line(data = plot_init, aes(x = Mean.Speed, y = Predicted, color = "brown1")) +
  geom_ribbon(data = plot_init, aes(x = Mean.Speed, y = Predicted, ymin = Lower, ymax = Upper), fill = "brown1", alpha = 0.15)+
  geom_point(data = d_CF, aes(x = Mean.Speed, y = Distance..m., color = "brown1")) +
  ylim(c(0,3100)) +
  ylab("Distance (m)") +
  xlab("Mean velocity (m/s)") +
  ggtitle("Mean velocity of total distance flown in colony-derived bees\nwhich initiated flight") +
  theme_bw() +
  scale_color_npg() +
  scale_fill_npg() +
  theme(legend.position = "none")  +
  theme(text = element_text(size=14)) 

ggsave("speed_dist_colonybees.png", plot = Colonybees_flight_plot, device = "png", width = 18, height = 15, units = "cm")

############### distance flown by size of male and female colony-derived bees ################
d_CF <- filter(d_C, Initiation == 1)
d_CF$Sex <- trimws(d_CF$Sex, which = "right")
d_CF$Sex <- as.factor(d_CF$Sex)

ggplot() +
  geom_point(data = d_CF, aes(x = Intertegular.distance..mm., y = Distance..m., color = Sex))

cmod1 <- glmer(Distance..m. ~ Intertegular.distance..mm. + Sex + Mean.Speed + (1|Colony) + (1|Mill) + 
                 (1|Group.size), nAGQ = 0, family = Gamma(link = log), data = d_CF)
summary(cmod1)

cmod2 <- glmer(Distance..m. ~ Intertegular.distance..mm. + Sex*Mean.Speed + (1|Colony) + (1|Mill) + 
                 (1|Group.size), nAGQ = 0, family = Gamma(link = log), data = d_CF)

summary(cmod2)

anova(cmod1, cmod2)
# mod1 better

cmod3 <- glmer(Distance..m. ~ Intertegular.distance..mm. + Sex + Mean.Speed + (1|Colony) + (1|Mill), nAGQ = 0, family = Gamma(link = log), data = d_CF)
summary(cmod3)
#  mod1 better

cmod4 <- glmer(Distance..m. ~ Intertegular.distance..mm.*Sex + Mean.Speed + (1|Colony) + (1|Mill), nAGQ = 0, family = Gamma(link = log), data = d_CF)
summary(cmod4)

anova(cmod1, cmod4)
# cmod1 better

# predict model 
temp <- d_CF[ , c("Mean.Speed", "Sex", "Intertegular.distance..mm.", "Colony", "Mill", "Group.size")]
summary(temp$Intertegular.distance..mm.)  

Fvals <- with(d_CF, seq(from = min(Intertegular.distance..mm.), to = max(Intertegular.distance..mm.), length.out = 100))

pp <- lapply(Fvals, function(j) {
  temp$Intertegular.distance..mm. <- j
  predict(cmod1, newdata = temp, type = "response")
})


# predicted values
pred_biome_F <- lapply(levels(d_CF$Sex), function(sex) {
  temp$Sex[] <- sex
  lapply(Fvals, function (j) {
    temp$Intertegular.distance..mm. <- j
    predict(cmod1, newdata = temp, type = "response")
  })
})


# get means and quartiles for all Fvals for each level Sex
plotdat2_F <- lapply(pred_biome_F, function(X) {
  temp <- t(sapply(X, function(x) {
    c(M=mean(x), quantile(x, c(0.25, 0.75)))
  }))
  temp <- as.data.frame(cbind(temp, Fvals))
  colnames(temp) <- c("Predicted", "Lower", "Upper", "Intertegular.distance..mm.")
  return(temp)
})

# combine to one data frame
plotdat2_F <- do.call(rbind, plotdat2_F)

# add sex levels
plotdat2_F$Sex <- factor(rep(levels(d_FF$Sex), each = length(Fvals)))

# plot 
C_plot <- ggplot() +
  geom_point(data = d_CF, aes(x = Intertegular.distance..mm., y = Distance..m., color = Sex)) +
  geom_line(data = plotdat2_F, aes(x = Intertegular.distance..mm., y = Predicted, color = Sex)) +
  geom_ribbon(data = plotdat2_F, aes(x = Intertegular.distance..mm., y = Predicted, ymin = Lower, ymax = Upper, fill = Sex), alpha = 0.1) +
  ylab("Distance (m)") +
  xlab("Intertegular distance (mm)") +
  ggtitle("Predicted distance flown of male and female colony-derived bees which initiated flight") +
  theme_bw() + 
  scale_color_npg()

ggsave("CF_plot.png", plot = C_plot, device = "png", width = 20, height = 15, units = "cm")


######## check affect of age on distance flown #######
d_Fem$Age.at.flight..days. <- as.factor(d_Fem$Age.at.flight..days.)

# all female bees
ggplot()+
  geom_boxplot(data = d_Fem, aes(x = Age.at.flight..days., y = Distance..m., fill = Age.at.flight..days.)) +
  xlab("Age at flight (days)") +
  ylab("Distance (m)") +
  ggtitle("Age of female bees at flight on distance flown")
scale_fill_npg()

# female bees which initiated flight 
d_FF$Age.at.flight..days. <- as.factor(d_FF$Age.at.flight..days.)

# boxplot
age_dist_bp_F70 <-  ggplot()+
  geom_boxplot(data = d_FF, aes(x = Age.at.flight..days., y = Distance..m., fill = Age.at.flight..days.)) +
  xlab("Age at flight (days)") +
  ylab("Distance (m)") +
  ggtitle("Age of female bees at flight on distance flown") +
  theme_minimal_hgrid()+
  theme(legend.position = "none") +
  theme(text = element_text(size=14)) +
  scale_fill_npg()


kruskal.test(Distance..m. ~ Age.at.flight..days., data = d_FF)
# chi-squared = 4.8151, df = 2, p-value = 0.09004 no significant difference in distributions of age of flight in females 

# get medians and means 
aggregate(d_FF[, 14], list(d_FF$Age.at.flight..days.), FUN = mean)
aggregate(d_FF[, 14], list(d_FF$Age.at.flight..days.), FUN = median)

ggsave("Age_distance_bp_female70.png", plot = age_dist_bp_F70, device = "png", width = 15, height = 15, units = "cm")
#  all males were flown at day 7 



